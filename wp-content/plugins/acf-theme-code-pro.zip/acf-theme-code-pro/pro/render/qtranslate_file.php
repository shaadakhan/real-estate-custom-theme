<?php
// qTranslate File field
// https://github.com/funkjedi/acf-qtranslate

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

include( ACFTC_PLUGIN_DIR_PATH . 'render/file.php' );
